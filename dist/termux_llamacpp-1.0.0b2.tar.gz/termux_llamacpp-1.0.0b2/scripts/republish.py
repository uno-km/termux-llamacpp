import os
import sys
import subprocess
from pathlib import Path

ROOT = Path(r"c:\Users\GAME\Desktop\uno-km\dev\termux-llamacpp")
PYPI_TOKEN = "pypi-AgEIcHlwaS5vcmcCJDU1YzAwZWFmLTk1NjYtNDBhNy04NzU2LTc5NDdhMWFmYTQ4MAACKlszLCJjODUwYmJjMS1lNmUwLTQ3MjQtOTBjMi1iZTg3ZTIxOGRkMjkiXQAABiAsoDontB_Jt7ey9ItJI3j6B-GlrR0LwGr_uQDEDuHbug"
NPM_TOKEN = "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"

# 1. Clean and build Python dist
for f in (ROOT / "dist").glob("*"):
    f.unlink()

subprocess.run([sys.executable, "-m", "build"], cwd=str(ROOT), check=True)
subprocess.run([sys.executable, "scripts/generate_and_verify_report.py"], cwd=str(ROOT), check=True)

# 2. Upload Python to PyPI
env = os.environ.copy()
env["PYTHONIOENCODING"] = "utf-8"
env["PYTHONUTF8"] = "1"
env["TWINE_USERNAME"] = "__token__"
env["TWINE_PASSWORD"] = PYPI_TOKEN

res_pypi = subprocess.run([sys.executable, "-m", "twine", "upload", "dist/*", "--skip-existing"], cwd=str(ROOT), env=env, capture_output=True)
print("PyPI Exit:", res_pypi.returncode)

# 3. Publish to npm
res_npm = subprocess.run(f"npm publish --//registry.npmjs.org/:_authToken={NPM_TOKEN} --access public", shell=True, cwd=str(ROOT), capture_output=True)
print("npm Exit:", res_npm.returncode)
