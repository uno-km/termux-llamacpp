import os
import json
import urllib.request
import urllib.error
import subprocess

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "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")
REPO_NAME = "termux-llamacpp"
ORG = "uno-km"

headers = {
    "Authorization": f"Bearer {GITHUB_TOKEN}",
    "Accept": "application/vnd.github+json",
    "User-Agent": "Antigravity-Agent/1.0",
    "X-GitHub-Api-Version": "2022-11-28",
}

# 1. Check if repo exists
url = f"https://api.github.com/repos/{ORG}/{REPO_NAME}"
req = urllib.request.Request(url, headers=headers)

repo_exists = False
try:
    with urllib.request.urlopen(req) as resp:
        if resp.status == 200:
            repo_exists = True
            print(f"[+] Repository {ORG}/{REPO_NAME} exists!")
except urllib.error.HTTPError as e:
    if e.code == 404:
        print(f"[*] Repository {ORG}/{REPO_NAME} does not exist yet. Creating...")
    else:
        print(f"[-] GitHub API error {e.code}: {e.read().decode()}")

# 2. Create if not exists
if not repo_exists:
    create_url = f"https://api.github.com/user/repos"
    payload = json.dumps({
        "name": REPO_NAME,
        "description": "Production-grade, prebuilt GGUF LLM runtime, model manager & OpenAI-compatible server for Android Termux & ARM64.",
        "homepage": "https://github.com/uno-km/termux-llamacpp",
        "private": False,
        "has_issues": True,
        "has_projects": True,
        "has_wiki": False,
    }).encode("utf-8")
    
    req_create = urllib.request.Request(create_url, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req_create) as resp:
            print(f"[+] Successfully created repository: {ORG}/{REPO_NAME}")
            repo_exists = True
    except urllib.error.HTTPError as e:
        print(f"[-] Error creating repo: {e.code} - {e.read().decode()}")

# 3. Update repository topics & metadata
if repo_exists:
    topics_url = f"https://api.github.com/repos/{ORG}/{REPO_NAME}/topics"
    topics_payload = json.dumps({
        "names": [
            "termux",
            "llamacpp",
            "llm",
            "android",
            "arm64",
            "gguf",
            "openai-api",
            "edge-ai",
            "termux-aichain",
            "zero-compilation"
        ]
    }).encode("utf-8")
    req_topics = urllib.request.Request(topics_url, data=topics_payload, headers=headers, method="PUT")
    try:
        with urllib.request.urlopen(req_topics) as resp:
            print("[+] Successfully set repository topics!")
    except urllib.error.HTTPError as e:
        print(f"[-] Failed to update topics: {e.code} - {e.read().decode()}")
